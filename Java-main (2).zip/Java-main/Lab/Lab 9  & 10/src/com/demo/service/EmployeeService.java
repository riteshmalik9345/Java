package com.demo.service;

import com.demo.beans.Employee;

public interface EmployeeService {

	void addNewObject();

	Employee[] displayObjects();

}
