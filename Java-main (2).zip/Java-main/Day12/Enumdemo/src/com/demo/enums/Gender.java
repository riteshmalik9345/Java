package com.demo.enums;

public enum Gender {
   Male,Female;
}
