
public class OuterClass {
	private int i;
	static class InnerClass{
		public void test() {
			System.out.println("in test");
		}
		
	}

}
