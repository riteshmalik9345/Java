
public class grade {
	public static void main(String[] args) {
		char grade = 'b';
		grade = (char)(grade+6);
		System.out.println(grade);
	}
}