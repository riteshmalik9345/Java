package com.demo.interfaces;

public interface MyGenericInterface<T> {
	T compare(T x,T y);
	

}
