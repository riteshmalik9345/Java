package com.demo.beans;

import com.demo.interfaces.I3;

public class MyClass11 implements I3{

	@Override
	public void funct11() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int funct12() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void funct21() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int funct22() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void f31() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void f32() {
		// TODO Auto-generated method stub
		
	}
	

}
